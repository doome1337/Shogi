Shogi 2013.11.18 Readme
==============================================

To use this program, the zip-file archive
program must be extracted manually into a 
target directory, using an extraction utility
such as winzip or 7-zip. The directory structure
of the zip archive must be preserved when
extracting to the target folder. Ensure that
all folders are completely extracted in order 
to prevent any errors from occurring. Following 
this, click the shogi.jar file to run the program.

The user's guide can be found in the parent 
directory, in two possible formats: 
UsersGuideMark2.pdf and UsersGuideMark2.odt.
The Javadoc can be found in the doc folder, 
under index.html. The source files can be 
found under the path mgci/jhdap/shogi/.


tl;dr - extract folder and click shogi.jar.


==============================================

Shogi program by:

Dmitry Andreevich Paramonov
Jiayin Huang